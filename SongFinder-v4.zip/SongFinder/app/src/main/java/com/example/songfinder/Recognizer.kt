package com.example.songfinder

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class SongHit(val title: String, val artist: String, val youtubeId: String? = null)

/** ACRCloud से गाना पहचानने का काम। */
object Recognizer {

    // ACRCloud console से (Projects → Audio & Video Recognition → SongFinder)
    const val HOST = "identify-ap-southeast-1.acrcloud.com"
    const val ACCESS_KEY = "4caa559088bacd5698a7c53a82737063"
    const val ACCESS_SECRET = "vuafw5YAHGGnfnbuAkfkljAWFQoUszbhrDomsSCm"

    /** आख़िरी कोशिश में क्या हुआ: गड़बड़ी की वजह जानने के लिए। */
    @Volatile
    var lastMessage: String = "no attempt made"

    /** Raw 16-bit mono PCM को WAV में बदलता है। */
    fun pcmToWav(pcm: ByteArray, sampleRate: Int): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray())
        header.putInt(36 + pcm.size)
        header.put("WAVE".toByteArray())
        header.put("fmt ".toByteArray())
        header.putInt(16)
        header.putShort(1)               // PCM
        header.putShort(1)               // mono
        header.putInt(sampleRate)
        header.putInt(sampleRate * 2)    // byte rate
        header.putShort(2)               // block align
        header.putShort(16)              // bits per sample
        header.put("data".toByteArray())
        header.putInt(pcm.size)
        return header.array() + pcm
    }

    private fun sign(timestamp: String): String {
        val stringToSign = "POST\n/v1/identify\n$ACCESS_KEY\naudio\n1\n$timestamp"
        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(ACCESS_SECRET.toByteArray(Charsets.UTF_8), "HmacSHA1"))
        return Base64.encodeToString(mac.doFinal(stringToSign.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    /** गाना मिला तो SongHit, नहीं मिला तो null (वजह lastMessage में)। */
    fun recognize(wav: ByteArray): SongHit? {
        val timestamp = (System.currentTimeMillis() / 1000).toString()
        val signature = sign(timestamp)
        val boundary = "----SongFinder" + System.currentTimeMillis()
        val nl = "\r\n"

        val conn = (URL("https://$HOST/v1/identify").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 8000
            readTimeout = 10000
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        try {
            conn.outputStream.use { out ->
                fun field(name: String, value: String) {
                    out.write("--$boundary$nl".toByteArray())
                    out.write("Content-Disposition: form-data; name=\"$name\"$nl$nl$value$nl".toByteArray())
                }
                field("access_key", ACCESS_KEY)
                field("sample_bytes", wav.size.toString())
                field("timestamp", timestamp)
                field("signature", signature)
                field("data_type", "audio")
                field("signature_version", "1")
                out.write("--$boundary$nl".toByteArray())
                out.write("Content-Disposition: form-data; name=\"sample\"; filename=\"clip.wav\"$nl".toByteArray())
                out.write("Content-Type: audio/wav$nl$nl".toByteArray())
                out.write(wav)
                out.write("$nl--$boundary--$nl".toByteArray())
                out.flush()
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }
            if (text == null) {
                lastMessage = "HTTP $code, empty reply"
                return null
            }
            val json = try {
                JSONObject(text)
            } catch (e: Exception) {
                lastMessage = "HTTP $code: " + text.take(80)
                return null
            }

            val status = json.optJSONObject("status")
            val statusCode = status?.optInt("code", -1) ?: -1
            val statusMsg = status?.optString("msg") ?: ""
            if (statusCode == 1001) {
                lastMessage = "no match found"
                return null
            }
            if (statusCode != 0) {
                lastMessage = "ACRCloud error $statusCode: $statusMsg".take(160)
                return null
            }

            val music = json.optJSONObject("metadata")
                ?.optJSONArray("music")
                ?.optJSONObject(0)
            if (music == null) {
                lastMessage = "no match found"
                return null
            }
            val title = music.optString("title")
            val artist = music.optJSONArray("artists")?.optJSONObject(0)?.optString("name") ?: ""
            if (title.isBlank()) {
                lastMessage = "empty title"
                return null
            }
            // अगर ACRCloud ने YouTube वीडियो की ID दी है तो सीधा वीडियो खुलेगा
            val vid = music.optJSONObject("external_metadata")
                ?.optJSONObject("youtube")
                ?.optString("vid")
                ?.takeIf { it.isNotBlank() }

            lastMessage = "found"
            return SongHit(title, artist, vid)
        } catch (e: Exception) {
            lastMessage = "network problem: ${e.javaClass.simpleName} ${e.message ?: ""}".take(120)
            throw e
        } finally {
            conn.disconnect()
        }
    }
}
