package com.example.songfinder

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean

/**
 * बैकग्राउंड में माइक से गाना सुनती है और स्क्रीन के बीच में छोटा सा
 * "Searching..." बॉक्स दिखाती है। यह बॉक्स छुआ नहीं जा सकता और फोकस नहीं लेता,
 * इसलिए पीछे का ऐप (Instagram आदि) बिना रुके चलता रहता है।
 */
class ListenService : Service() {

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val MAX_LISTEN_MS = 25_000L   // 25 सेकंड की लिमिट
        private const val FIRST_TRY_MS = 4_000L     // पहली कोशिश 5 सेकंड बाद
        private const val RETRY_EVERY_MS = 3_000L   // फिर हर 4 सेकंड पर
        private const val CLIP_SECONDS = 8         // हर बार आख़िरी 10 सेकंड भेजो
        private const val CHANNEL_ID = "listen"
    }

    private val found = AtomicBoolean(false)
    private val inFlight = AtomicBoolean(false)
    @Volatile private var running = false
    @Volatile private var lastPeak = 0
    private var label: TextView? = null
    private val ui = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private lateinit var windowManager: WindowManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_NOT_STICKY   // पहले से सुन रहा है

        try {
            startAsForeground()
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        running = true
        found.set(false)
        inFlight.set(false)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
        startListening()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Listening", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Listening for song")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }
    }

    private fun showOverlay() {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(22), dp(22), dp(18))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E60B0B14"))
                cornerRadius = dp(28).toFloat()
            }
        }
        // ✕ बटन: दबाने पर सुनना बंद और बॉक्स गायब
        card.addView(
            TextView(this).apply {
                text = "✕"
                setTextColor(Color.parseColor("#B0B0C0"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                setPadding(dp(16), dp(2), dp(4), dp(6))
                setOnClickListener { cleanup() }
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.END }
        )
        card.addView(PulseView(this), LinearLayout.LayoutParams(dp(150), dp(150)))
        card.addView(
            TextView(this).apply {
                this@ListenService.label = this
                text = "Searching..."
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                gravity = Gravity.CENTER
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        try {
            windowManager.addView(card, params)
            overlay = card
        } catch (e: Exception) {
            // ओवरले न दिखे तब भी सुनना जारी रहेगा
        }
    }

    @SuppressLint("MissingPermission")
    private fun startListening() {
        Thread {
            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val recorder = try {
                AudioRecord(
                    MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, SAMPLE_RATE * 2)
                )
            } catch (e: Exception) {
                null
            }
            if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder?.release()
                ui.post { label?.text = "Mic could not start" }
                Thread.sleep(6000)
                cleanup()
                return@Thread
            }

            val pcm = ByteArrayOutputStream()
            val buf = ByteArray(4096)
            var nextTry = FIRST_TRY_MS
            val start = SystemClock.elapsedRealtime()
            recorder.startRecording()

            try {
                while (running && !found.get()) {
                    val elapsed = SystemClock.elapsedRealtime() - start
                    if (elapsed >= MAX_LISTEN_MS) break

                    val n = recorder.read(buf, 0, buf.size)
                    if (n > 0) pcm.write(buf, 0, n)

                    // गाना पहचानने की कोशिश: जैसे ही पहचान ले, तुरंत खुल जाएगा
                    if (elapsed >= nextTry && inFlight.compareAndSet(false, true)) {
                        nextTry = elapsed + RETRY_EVERY_MS
                        val all = pcm.toByteArray()
                        val keep = SAMPLE_RATE * 2 * CLIP_SECONDS
                        val clip = if (all.size > keep) all.copyOfRange(all.size - keep, all.size) else all
                        Thread { tryRecognize(clip) }.start()
                    }
                }
            } finally {
                try { recorder.stop() } catch (e: Exception) { }
                recorder.release()
            }

            // 25 सेकंड से ठीक पहले भेजी गई आख़िरी कोशिश का जवाब थोड़ा इंतज़ार करके देखो
            val waitStart = SystemClock.elapsedRealtime()
            while (running && inFlight.get() && !found.get() &&
                SystemClock.elapsedRealtime() - waitStart < 10_000
            ) {
                Thread.sleep(100)
            }

            // कुछ नहीं मिला तो बॉक्स हट जाए
            if (running && !found.get()) {
                val msg = "Not found: ${Recognizer.lastMessage} (mic level $lastPeak)"
                ui.post {
                    label?.apply {
                        text = msg
                        maxWidth = dp(240)
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    }
                }
                // संदेश पढ़ने के लिए 15 सेकंड रुको (✕ दबाने पर जल्दी बंद हो जाएगा)
                var waited = 0
                while (running && waited < 150) {
                    Thread.sleep(100)
                    waited++
                }
                cleanup()
            }
        }.start()
    }

    private fun tryRecognize(pcmClip: ByteArray) {
        try {
            // माइक में कितनी आवाज़ आई (0 के पास = लगभग चुप्पी)
            var peak = 0
            var i = 0
            while (i + 1 < pcmClip.size) {
                val s = ((pcmClip[i + 1].toInt() shl 8) or (pcmClip[i].toInt() and 0xFF)).toShort().toInt()
                if (Math.abs(s) > peak) peak = Math.abs(s)
                i += 2
            }
            lastPeak = peak

            val wav = Recognizer.pcmToWav(pcmClip, SAMPLE_RATE)
            val hit = Recognizer.recognize(wav)
            if (hit != null && found.compareAndSet(false, true)) {
                ui.post { openLink(hit) }
                cleanup()
            }
        } catch (e: Exception) {
            // नेटवर्क की दिक्कत: अगली कोशिश में फिर देखेंगे
        } finally {
            inFlight.set(false)
        }
    }

    /** सिर्फ YouTube पर खुलेगा (ऐप न हो तो ब्राउज़र में YouTube)। Spotify कभी नहीं। */
    private fun openLink(hit: SongHit) {
        val query = URLEncoder.encode("${hit.title} ${hit.artist}".trim(), "UTF-8")
        // YouTube की वीडियो ID मिली तो सीधा वीडियो, नहीं तो YouTube पर सर्च
        val url = if (!hit.youtubeId.isNullOrBlank())
            Uri.parse("https://www.youtube.com/watch?v=${hit.youtubeId}")
        else
            Uri.parse("https://www.youtube.com/results?search_query=$query")
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, url)
                    .setPackage("com.google.android.youtube")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: ActivityNotFoundException) {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$query"))
                    .addCategory(Intent.CATEGORY_BROWSABLE)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun cleanup() {
        running = false
        ui.post {
            removeOverlay()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun removeOverlay() {
        overlay?.let {
            try { windowManager.removeView(it) } catch (e: Exception) { }
        }
        overlay = null
    }

    override fun onDestroy() {
        running = false
        removeOverlay()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
