package com.example.songfinder

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** फैलते हुए रिंग्स + बीच में म्यूज़िक बार्स: ऐसा लगे कि ऐप गाना सुन रहा है। */
class PulseView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val accent = Color.parseColor("#7C4DFF")

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * density
        color = accent
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = accent
    }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 6f * density
        strokeCap = Paint.Cap.ROUND
    }

    private var t = 0f

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val maxR = min(width, height) / 2f
        val coreR = maxR * 0.32f

        // तीन रिंग्स, एक-एक करके बाहर फैलती हुईं
        for (i in 0 until 3) {
            val p = (t + i / 3f) % 1f
            ringPaint.alpha = ((1f - p) * 170).toInt()
            canvas.drawCircle(cx, cy, coreR + (maxR - coreR) * p, ringPaint)
        }

        canvas.drawCircle(cx, cy, coreR, corePaint)

        // बीच में equalizer जैसे 4 बार्स
        val phase = t * 2f * PI.toFloat() * 2f
        for (i in 0 until 4) {
            val h = coreR * (0.35f + 0.9f * abs(sin(phase + i * 0.9f)))
            val x = cx + (i - 1.5f) * 14f * density
            canvas.drawLine(x, cy - h / 2f, x, cy + h / 2f, barPaint)
        }
    }
}
