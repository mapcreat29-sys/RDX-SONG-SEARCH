package com.example.songfinder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/**
 * यह एक पारदर्शी "लॉन्चर" है। इसकी अपनी कोई स्क्रीन नहीं है।
 * आइकन दबाते ही यह सुनने वाली सर्विस चालू करके तुरंत बंद हो जाती है,
 * इसलिए पीछे का ऐप (जैसे Instagram) जैसा था वैसा ही दिखता और चलता रहता है।
 */
class MainActivity : Activity() {

    private var waitingForOverlaySetting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        proceed()
    }

    private fun proceed() {
        // 1) माइक की परमिशन (सिर्फ पहली बार)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        // 2) "Display over other apps" की परमिशन (सिर्फ पहली बार)
        if (!Settings.canDrawOverlays(this)) {
            waitingForOverlaySetting = true
            Toast.makeText(
                this, "Song Finder को ON करें, फिर वापस आएँ", Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        // 3) सुनना शुरू करो और यह पारदर्शी स्क्रीन बंद कर दो
        startForegroundService(Intent(this, ListenService::class.java))
        finish()
        overridePendingTransition(0, 0)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            proceed()
        } else {
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        if (waitingForOverlaySetting) {
            waitingForOverlaySetting = false
            if (Settings.canDrawOverlays(this)) proceed() else finish()
        }
    }
}
