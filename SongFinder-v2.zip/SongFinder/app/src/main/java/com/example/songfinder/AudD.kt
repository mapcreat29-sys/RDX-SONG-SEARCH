package com.example.songfinder

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class SongHit(val title: String, val artist: String)

object AudD {

    // यहाँ अपनी AudD API key डालें (https://dashboard.audd.io से मिलती है)
    const val API_TOKEN = "5f130d662402ba1d7abcec87e45b26fc"

    /** आख़िरी कोशिश में क्या हुआ: गड़बड़ी की वजह जानने के लिए। */
    @Volatile
    var lastMessage: String = "no attempt made"

    /** Raw 16-bit mono PCM को WAV में बदलता है। */
    fun pcmToWav(pcm: ByteArray, sampleRate: Int): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray())
        header.putInt(36 + pcm.size)
        header.put("WAVE".toByteArray())
        header.put("fmt ".toByteArray())
        header.putInt(16)
        header.putShort(1)               // PCM
        header.putShort(1)               // mono
        header.putInt(sampleRate)
        header.putInt(sampleRate * 2)    // byte rate
        header.putShort(2)               // block align
        header.putShort(16)              // bits per sample
        header.put("data".toByteArray())
        header.putInt(pcm.size)
        return header.array() + pcm
    }

    /** गाना मिला तो SongHit, नहीं मिला तो null (वजह lastMessage में)। */
    fun recognize(wav: ByteArray): SongHit? {
        val boundary = "----SongFinder" + System.currentTimeMillis()
        val nl = "\r\n"
        val conn = (URL("https://api.audd.io/").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 8000
            readTimeout = 10000
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        try {
            conn.outputStream.use { out ->
                out.write("--$boundary$nl".toByteArray())
                out.write("Content-Disposition: form-data; name=\"api_token\"$nl$nl$API_TOKEN$nl".toByteArray())
                out.write("--$boundary$nl".toByteArray())
                out.write("Content-Disposition: form-data; name=\"file\"; filename=\"clip.wav\"$nl".toByteArray())
                out.write("Content-Type: audio/wav$nl$nl".toByteArray())
                out.write(wav)
                out.write("$nl--$boundary--$nl".toByteArray())
                out.flush()
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }
            if (text == null) {
                lastMessage = "HTTP $code, empty reply"
                return null
            }
            val json = try {
                JSONObject(text)
            } catch (e: Exception) {
                lastMessage = "HTTP $code: " + text.take(80)
                return null
            }
            val err = json.optJSONObject("error")
            if (err != null) {
                lastMessage = "AudD error ${err.optInt("error_code")}: ${err.optString("error_message")}".take(160)
                return null
            }
            val result = json.optJSONObject("result")
            if (result == null) {
                lastMessage = "no match found"
                return null
            }
            val title = result.optString("title")
            val artist = result.optString("artist")
            if (title.isBlank()) {
                lastMessage = "empty title"
                return null
            }
            lastMessage = "found"
            return SongHit(title, artist)
        } catch (e: Exception) {
            lastMessage = "network problem: ${e.javaClass.simpleName} ${e.message ?: ""}".take(120)
            throw e
        } finally {
            conn.disconnect()
        }
    }
}
