package com.example.songfinder

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.io.ByteArrayOutputStream
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val MAX_LISTEN_MS = 25_000L   // 25 सेकंड की लिमिट
        private const val FIRST_TRY_MS = 5_000L     // पहली कोशिश 5 सेकंड बाद
        private const val RETRY_EVERY_MS = 4_000L   // फिर हर 4 सेकंड पर
        private const val CLIP_SECONDS = 10         // हर बार आख़िरी 10 सेकंड भेजो
        private const val REQ_MIC = 1
    }

    private val found = AtomicBoolean(false)
    private val inFlight = AtomicBoolean(false)
    @Volatile private var running = false
    private var awaitingPermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.parseColor("#0B0B14")
        window.navigationBarColor = Color.parseColor("#0B0B14")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0B0B14"))
        }
        root.addView(PulseView(this), LinearLayout.LayoutParams(dp(280), dp(280)))

        val label = TextView(this).apply {
            text = "Searching..."
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            letterSpacing = 0.05f
        }
        root.addView(
            label,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(24) }
        )
        setContentView(root)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            awaitingPermission = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        awaitingPermission = false
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            finish()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startListening() {
        if (running) return
        running = true

        Thread {
            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val recorder = try {
                AudioRecord(
                    MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, SAMPLE_RATE * 2)
                )
            } catch (e: Exception) {
                null
            }
            if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder?.release()
                runOnUiThread { finish() }
                return@Thread
            }

            val pcm = ByteArrayOutputStream()
            val buf = ByteArray(4096)
            var nextTry = FIRST_TRY_MS
            val start = SystemClock.elapsedRealtime()
            recorder.startRecording()

            try {
                while (running && !found.get()) {
                    val elapsed = SystemClock.elapsedRealtime() - start
                    if (elapsed >= MAX_LISTEN_MS) break

                    val n = recorder.read(buf, 0, buf.size)
                    if (n > 0) pcm.write(buf, 0, n)

                    // गाना पहचानने की कोशिश: जैसे ही पहचान ले, तुरंत खुल जाएगा
                    if (elapsed >= nextTry && inFlight.compareAndSet(false, true)) {
                        nextTry = elapsed + RETRY_EVERY_MS
                        val all = pcm.toByteArray()
                        val keep = SAMPLE_RATE * 2 * CLIP_SECONDS
                        val clip = if (all.size > keep) all.copyOfRange(all.size - keep, all.size) else all
                        Thread { tryRecognize(clip) }.start()
                    }
                }
            } finally {
                try { recorder.stop() } catch (e: Exception) { }
                recorder.release()
            }

            // 25 सेकंड से ठीक पहले भेजी गई आख़िरी कोशिश का जवाब थोड़ा इंतज़ार करके देखो
            val waitStart = SystemClock.elapsedRealtime()
            while (running && inFlight.get() && !found.get() &&
                SystemClock.elapsedRealtime() - waitStart < 10_000
            ) {
                Thread.sleep(100)
            }

            // 25 सेकंड में कुछ नहीं मिला तो स्क्रीन हट जाए
            if (running && !found.get()) {
                runOnUiThread { finish() }
            }
        }.start()
    }

    private fun tryRecognize(pcmClip: ByteArray) {
        try {
            val wav = AudD.pcmToWav(pcmClip, SAMPLE_RATE)
            val hit = AudD.recognize(wav)
            if (hit != null && found.compareAndSet(false, true)) {
                runOnUiThread {
                    openLink(hit)
                    finish()
                }
            }
        } catch (e: Exception) {
            // नेटवर्क की दिक्कत: अगली कोशिश में फिर देखेंगे
        } finally {
            inFlight.set(false)
        }
    }

    /** सिर्फ YouTube पर खुलेगा (ऐप न हो तो ब्राउज़र में YouTube)। Spotify कभी नहीं। */
    private fun openLink(hit: SongHit) {
        val query = URLEncoder.encode("${hit.title} ${hit.artist}".trim(), "UTF-8")
        val url = Uri.parse("https://www.youtube.com/results?search_query=$query")
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, url).setPackage("com.google.android.youtube")
            )
        } catch (e: ActivityNotFoundException) {
            startActivity(
                Intent(Intent.ACTION_VIEW, url).addCategory(Intent.CATEGORY_BROWSABLE)
            )
        }
    }

    override fun onStop() {
        super.onStop()
        // होम दबाने पर माइक बंद कर दो (permission डायलॉग के समय नहीं)
        if (!awaitingPermission && !isFinishing) {
            running = false
            finish()
        }
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
